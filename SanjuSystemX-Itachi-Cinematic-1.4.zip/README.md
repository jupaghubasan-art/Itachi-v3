# SanjuSystemX 1.4.0

## Itachi startup cinematic
- Uses the supplied Itachi/Sharingan image for the app launcher icon.
- On Game Space launch, the supplied Itachi image is shown for a 5-second cinematic.
- The eye starts visually closed and smoothly opens to reveal the Sharingan.
- A subtle red Sharingan pulse and vignette are added after the reveal.
- The supplied `liberei_a_intro_do_Itachi.mp3` is played from the start of the intro.
- The Game Space shell fades in after the 5-second intro and initialization are ready.

## Build
GitHub Actions automatically locates the Gradle project root instead of assuming a repository folder name.
