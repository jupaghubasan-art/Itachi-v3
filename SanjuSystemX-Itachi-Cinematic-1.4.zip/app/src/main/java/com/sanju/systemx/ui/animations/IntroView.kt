package com.sanju.systemx.ui.animations

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import com.sanju.systemx.R
import kotlin.math.max

/**
 * Five-second Itachi startup cinematic.
 * The supplied Itachi image is shown with a simulated eyelid opening: a dark mask
 * starts closed over the Sharingan and smoothly opens until the eye is fully revealed.
 */
class IntroView(ctx: Context) : View(ctx) {
    var t = 0f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }

    private val image = BitmapFactory.decodeResource(resources, R.drawable.itachi_intro_image)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val vignettePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d get() = resources.displayMetrics.density

    // Eye position in the supplied 864x1536 reference image.
    private val eye = RectF(260f, 565f, 755f, 930f)

    private fun easeInOut(v: Float): Float {
        val x = v.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }

    private fun phase(v: Float, a: Float, b: Float): Float = ((v - a) / (b - a)).coerceIn(0f, 1f)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Color.BLACK)

        // Center-crop the supplied portrait into the landscape intro.
        val scale = max(w / image.width, h / image.height)
        val dw = image.width * scale
        val dh = image.height * scale
        val left = (w - dw) / 2f
        val top = (h - dh) / 2f
        val dst = RectF(left, top, left + dw, top + dh)
        paint.alpha = (255 * phase(t, 0f, 0.28f)).toInt()
        c.drawBitmap(image, null, dst, paint)

        // Calculate where the Sharingan eye lands after the center-crop.
        val ex1 = left + eye.left * scale
        val ex2 = left + eye.right * scale
        val ey1 = top + eye.top * scale
        val ey2 = top + eye.bottom * scale
        val ecx = (ex1 + ex2) / 2f
        val ecy = (ey1 + ey2) / 2f

        // Keep the eye visually closed at first, then open it over ~2.6 seconds.
        val open = easeInOut(phase(t, 0.12f, 0.56f))
        val fullH = (ey2 - ey1) * 0.94f
        val slitH = max(2f * d, fullH * (0.025f + 0.975f * open))
        val openTop = ecy - slitH / 2f
        val openBottom = ecy + slitH / 2f

        // Dark eyelids above and below the opening.
        maskPaint.shader = LinearGradient(0f, ey1, 0f, openTop,
            intArrayOf(0xFF050507.toInt(), 0xFF0A090D.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRect(ex1 - 24f * d, ey1 - 20f * d, ex2 + 24f * d, openTop, maskPaint)
        maskPaint.shader = LinearGradient(0f, openBottom, 0f, ey2,
            intArrayOf(0xFF0A090D.toInt(), 0xFF050507.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRect(ex1 - 24f * d, openBottom, ex2 + 24f * d, ey2 + 20f * d, maskPaint)
        maskPaint.shader = null

        // Extra darkness at the beginning makes the opening feel cinematic.
        val pre = 1f - easeInOut(phase(t, 0.02f, 0.24f))
        if (pre > 0f) {
            maskPaint.color = Color.argb((150f * pre).toInt(), 0, 0, 0)
            c.drawRect(0f, 0f, w, h, maskPaint)
        }

        // Sharingan reveal pulse after the eye opens.
        val pulsePhase = phase(t, 0.52f, 0.78f)
        if (pulsePhase > 0f) {
            val pulse = 1f - phase(pulsePhase, 0.15f, 1f)
            val alpha = (70f + 90f * pulse).toInt().coerceIn(0, 180)
            glowPaint.shader = LinearGradient(ex1, ecy, ex2, ecy,
                intArrayOf(Color.argb(0, 255, 0, 0), Color.argb(alpha, 255, 24, 42), Color.argb(0, 255, 0, 0)),
                null, Shader.TileMode.CLAMP)
            glowPaint.style = Paint.Style.FILL
            c.drawOval(RectF(ex1 - 18f * d, ey1 - 12f * d, ex2 + 18f * d, ey2 + 12f * d), glowPaint)
            glowPaint.shader = null
        }

        // Subtle vignette keeps attention on the eye without adding text or logos.
        vignettePaint.shader = android.graphics.RadialGradient(
            w / 2f, h / 2f, max(w, h) * 0.72f,
            intArrayOf(0x00000000, 0x22000000, 0xAA000000.toInt()),
            floatArrayOf(0.48f, 0.78f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, vignettePaint)
        vignettePaint.shader = null
    }
}
