package com.sanju.systemx.gamespace

import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.components.MATCH
import com.sanju.systemx.ui.components.SkewCardDrawable
import com.sanju.systemx.ui.components.WRAP
import com.sanju.systemx.ui.components.iconOf
import com.sanju.systemx.ui.components.lp
import com.sanju.systemx.ui.components.smallBtn
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import kotlinx.coroutines.launch

/** GAMES: detected + user-added launchable apps. Selected card glows red. */
fun GameSpaceActivity.gamesSection(): View {
    val act = this
    val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(6), dp(14), dp(10)) }
    wrap.addView(label("GAME LIBRARY", 12f, Pal.RED, true).apply { letterSpacing = 0.15f })
    val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
    val row = LinearLayout(this).apply { setPadding(0, dp(8), 0, dp(8)) }

    fun gameCard(g: GameInfo): View {
        val sel = g.pkg == vm.selected.value
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = SkewCardDrawable(sel)
            setPadding(dp(30), dp(14), dp(30), dp(12))
            isClickable = true
            contentDescription = g.label
            setOnClickListener {
                prefs.setS("game", g.pkg); vm.selected.value = g.pkg; click(); renderSection()
            }
            if (g.added) setOnLongClickListener {
                lifecycleScope.launch {
                    if (ask("Remove ${g.label}?", "It will be removed from your Game Space library only.", "REMOVE")) {
                        GameRepository.remove(prefs, g.pkg)
                        vm.games.value = GameRepository.load(applicationContext, prefs)
                    }
                }
                true
            }
        }
        c.addView(ImageView(this).apply { setImageDrawable(iconOf(g.pkg)) }, lp(dp(56), dp(56)))
        c.addView(label(g.label, 13f, Pal.text, true).apply { gravity = Gravity.CENTER; maxLines = 2 }, lp(MATCH, WRAP).apply { topMargin = dp(6) })
        c.addView(label(g.pkg, 9f, Pal.sub).apply { gravity = Gravity.CENTER; maxLines = 1 }, lp(MATCH, WRAP))
        c.addView(smallBtn(if (sel) "SELECTED" else "SELECT") {
            prefs.setS("game", g.pkg); vm.selected.value = g.pkg; click(); renderSection()
        }, lp(WRAP, WRAP).apply { topMargin = dp(6) })
        return c
    }

    vm.games.value.forEach { row.addView(gameCard(it), lp(dp(230), WRAP).apply { marginEnd = dp(10) }) }
    val add = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = SkewCardDrawable(false)
        setPadding(dp(30), dp(14), dp(30), dp(12))
    }
    add.addView(smallBtn("+ ADD GAME") {
        act.lifecycleScope.launch {
            val all = GameRepository.allLaunchable(applicationContext)
            AlertDialog.Builder(act).setTitle("ADD GAME")
                .setItems(all.map { it.label }.toTypedArray()) { _, i ->
                    GameRepository.add(prefs, all[i].pkg)
                    act.lifecycleScope.launch {
                        vm.games.value = GameRepository.load(applicationContext, prefs)
                        renderSection()
                    }
                }
                .setNegativeButton("CANCEL", null).show()
        }
    })
    row.addView(add, lp(dp(170), WRAP))
    hs.addView(row)
    wrap.addView(hs, lp(MATCH, WRAP))
    if (vm.games.value.isEmpty()) wrap.addView(label("No games detected. Use ADD GAME to pick any installed app.", 12f, Pal.sub))
    wrap.addView(label("Long-press a game you added to remove it.", 10f, Pal.sub), lp(MATCH, WRAP).apply { topMargin = dp(4) })
    return wrap
}
