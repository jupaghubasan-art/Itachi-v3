package com.sanju.systemx.gamespace

import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import com.sanju.systemx.R
import com.sanju.systemx.device.DeviceInfoProvider
import com.sanju.systemx.optimizer.OptimizationProfile
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.resolution.ResolutionManager
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.box
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.components.AMBER
import com.sanju.systemx.ui.components.SkewCardDrawable
import com.sanju.systemx.ui.components.StatRow
import com.sanju.systemx.ui.components.WRAP
import com.sanju.systemx.ui.components.MATCH
import com.sanju.systemx.ui.components.iconOf
import com.sanju.systemx.ui.components.lp
import com.sanju.systemx.ui.components.smallBtn
import com.sanju.systemx.ui.components.weight
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.ui.put
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

/** HOME: selected game (focus) on the left, real-time performance on the right, BOOST & PLAY below the card. */
fun GameSpaceActivity.homeSection(): View {
    val act = this
    val g = vm.selectedGame()
    val profile = OptimizationProfile.fromName(prefs.getS("profile", "BALANCED"))
    val root = LinearLayout(this).apply { setPadding(dp(14), dp(6), dp(14), dp(10)) }

    val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val card = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(34), dp(16), dp(34), dp(14))
        background = SkewCardDrawable(g != null)
    }
    if (g == null) {
        card.addView(label("NO GAME SELECTED", 16f, Pal.text, true))
        card.addView(label(getString(R.string.select_game_hint), 12f, Pal.sub))
        card.addView(smallBtn("SELECT GAME") { select(GameSpaceActivity.Section.GAMES) }, lp(WRAP, WRAP).apply { topMargin = dp(8) })
    } else {
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageDrawable(iconOf(g.pkg)); contentDescription = g.label }, lp(dp(60), dp(60)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        info.addView(label(g.label.uppercase(), 16f, Pal.text, true))
        info.addView(label(g.pkg, 11f, Pal.sub))
        info.addView(label("STATUS  READY", 12f, Pal.GREEN, true))
        info.addView(label("PROFILE  ${profile.title}", 12f, Pal.text))
        head.addView(info, lp(0, WRAP, 1f))
        card.addView(head)
        val btns = LinearLayout(this)
        btns.addView(smallBtn("SELECT") { select(GameSpaceActivity.Section.GAMES) }, lp(0, WRAP, 1f))
        btns.addView(smallBtn("BOOST") { startBoost(false) }, lp(0, WRAP, 1f).apply { marginStart = dp(6) })
        btns.addView(smallBtn("LAUNCH") { launchGame(g) }, lp(0, WRAP, 1f).apply { marginStart = dp(6) })
        card.addView(btns, lp(MATCH, WRAP).apply { topMargin = dp(10) })
    }
    left.addView(card, lp(MATCH, WRAP))

    if (prefs.getB("res_modified", false)) {
        val warn = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        warn.addView(label("⚠ RESOLUTION MODIFIED", 12f, AMBER, true), lp(0, WRAP, 1f))
        warn.addView(smallBtn("RESET") {
            act.lifecycleScope.launch {
                if (ask("Reset resolution?", "Shizuku will run:\nwm size reset", "RESET")) {
                    val r = ResolutionManager.reset(prefs)
                    toast(if (r.code == 0) "Native resolution restored." else "Reset failed: ${r.out}")
                    renderSection()
                }
            }
        }, lp(WRAP, WRAP))
        left.addView(warn, lp(MATCH, WRAP))
    }
    vm.lastSession?.let { left.put(label("LAST SESSION  $it", 11f, Pal.sub), 8) }

    val boost = btn(getString(R.string.boost_play)) { v -> pressAnim(v); startBoost(true) }
        .apply { textSize = 16f; minimumHeight = dp(54); contentDescription = getString(R.string.boost_play) }
    left.put(boost, 10)

    // Real-time performance (only real, labelled values)
    val rows = LinkedHashMap<String, StatRow>()
    val panel = box("REAL-TIME PERFORMANCE")
    fun row(k: String, init: String) { val r = StatRow(act, k, init); rows[k] = r; panel.addView(r.view) }
    val (sw, sh) = DeviceInfoProvider.screen(this)
    row("GAME FPS", "UNAVAILABLE")
    row("REFRESH", "${DisplayCtl.hz(this)} Hz")
    row("RESOLUTION", "$sw × $sh" + if (prefs.getB("res_modified", false)) " (modified)" else "")
    row("SYSTEM RAM", "…")
    row("BATTERY TEMP", "…")
    row("BATTERY", "…")
    row("GRAPHICS API", vm.graphics.value?.apiSummary ?: "Loading…")
    row("PROFILE", profile.title)
    panel.put(label(getString(R.string.game_fps_unavailable), 10f, Pal.sub), 6)

    liveUpdater = { s ->
        rows.getValue("REFRESH").value.text = "${DisplayCtl.hz(act)} Hz"
        rows.getValue("SYSTEM RAM").value.text = s.ramText
        rows.getValue("BATTERY TEMP").value.text = s.tempC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "Unavailable"
        rows.getValue("BATTERY").value.text = (if (s.battery >= 0) "${s.battery}%" else "n/a") + if (s.charging) " · charging" else ""
    }

    root.weight(left, 1.1f)
    root.weight(panel, 1f, dp(12))
    return root
}
