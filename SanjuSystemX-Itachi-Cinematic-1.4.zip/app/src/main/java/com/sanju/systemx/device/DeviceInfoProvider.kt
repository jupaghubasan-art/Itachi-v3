package com.sanju.systemx.device

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.util.DisplayMetrics
import com.sanju.systemx.resolution.DisplayCtl
import java.util.Locale

object DeviceInfoProvider {
    /** Current effective screen size as short × long side (follows `wm size` overrides). */
    @Suppress("DEPRECATION")
    fun screen(a: Activity): Pair<Int, Int> {
        val m = DisplayMetrics()
        DisplayCtl.display(a).getRealMetrics(m)
        return minOf(m.widthPixels, m.heightPixels) to maxOf(m.widthPixels, m.heightPixels)
    }

    private fun gb(b: Long) = String.format(Locale.US, "%.1f GB", b / 1073741824f)

    fun rows(a: Activity, gfx: GraphicsInfo?): List<Pair<String, String>> {
        val am = a.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val sf = StatFs(Environment.getDataDirectory().path)
        val (w, h) = screen(a)
        return listOf(
            "MODEL" to Build.MODEL,
            "MANUFACTURER" to Build.MANUFACTURER,
            "ANDROID" to Build.VERSION.RELEASE,
            "SDK" to Build.VERSION.SDK_INT.toString(),
            "RAM" to gb(mi.totalMem),
            "STORAGE" to gb(sf.availableBytes) + " free",
            "SCREEN" to "$w × $h",
            "REFRESH" to "${DisplayCtl.hz(a)} Hz",
            "CPU" to "${Runtime.getRuntime().availableProcessors()} cores",
            "GPU" to (gfx?.renderer ?: "Unavailable"),
            "GRAPHICS API" to (gfx?.apiSummary ?: "Unavailable")
        )
    }
}
