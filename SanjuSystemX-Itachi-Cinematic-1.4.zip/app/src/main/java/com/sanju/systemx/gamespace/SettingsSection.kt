package com.sanju.systemx.gamespace

import android.content.Intent
import android.content.pm.ActivityInfo
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.sanju.systemx.MainActivity
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.GsLog
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.box
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.components.weight
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.ui.put
import com.sanju.systemx.ui.switchRow
import kotlinx.coroutines.launch

/** SETTINGS: every toggle here controls real behaviour. */
fun GameSpaceActivity.settingsSection(): View {
    val act = this
    val root = LinearLayout(this).apply { setPadding(dp(14), dp(6), dp(14), dp(10)) }
    val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    root.weight(left, 1f)
    root.weight(right, 1f, dp(12))

    left.put(box("GAME SPACE").apply {
        put(switchRow("Dark theme", prefs.getB("dark", true)) { prefs.setB("dark", it); recreate() }, 2)
        put(switchRow("Animations (intro & transitions)", prefs.getB("anim", true)) { prefs.setB("anim", it); Pal.anim = it }, 2)
        put(switchRow("Haptic feedback", prefs.getB("haptic", true)) { prefs.setB("haptic", it); Pal.haptic = it }, 2)
        put(switchRow("Sound effects", prefs.getB("sound", true)) { prefs.setB("sound", it); sfx.enabled = it }, 2)
        put(switchRow("Auto monitor", prefs.getB("autoMon", true)) { prefs.setB("autoMon", it) }, 2)
        put(switchRow("Keep screen awake", prefs.getB("awake", false)) { engine.setAwake(it) }, 2)
        put(switchRow("Auto landscape", prefs.getB("autoLandscape", true)) {
            prefs.setB("autoLandscape", it)
            requestedOrientation = if (it) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }, 2)
        put(switchRow("Auto Shizuku check at startup", prefs.getB("autoShizuku", true)) { prefs.setB("autoShizuku", it) }, 2)
        put(switchRow("Auto launch game after BOOST & PLAY", prefs.getB("autoLaunch", true)) { prefs.setB("autoLaunch", it) }, 2)
        put(switchRow("Show device stats (Monitor)", prefs.getB("showStats", true)) { prefs.setB("showStats", it) }, 2)
        put(switchRow("Game Space visual mode", prefs.getB("anime", false)) { prefs.setB("anime", it); applyVisual(it) }, 2)
        put(label("Visual mode affects the Game Space UI only (saturation and contrast). It never modifies or filters any game.", 11f, Pal.sub), 4)
    }, 0)

    right.put(box("TOOLS").apply {
        put(btn("LEGACY / ADVANCED TOOLS", false) { startActivity(Intent(act, MainActivity::class.java)) }, 4)
        put(btn("VIEW DEBUG LOG", false) {
            AlertDialog.Builder(act).setTitle("Debug log").setMessage(GsLog.dump()).setPositiveButton("CLOSE", null).show()
        }, 8)
        put(btn("RESET SETTINGS", false) {
            act.lifecycleScope.launch {
                if (ask("Reset settings?", "All Game Space settings, the selected game and the profile return to defaults. The screen resolution is not changed (use RESET RESOLUTION for that).", "RESET")) {
                    val keepMod = prefs.getB("res_modified", false)
                    prefs.clear(); prefs.setB("res_modified", keepMod)
                    DisplayCtl.reset(act); engine.setAwake(false); applyVisual(false)
                    recreate()
                }
            }
        }, 8)
    }, 0)
    right.put(box("ABOUT").apply {
        put(label("SANJU SYSTEM X", 16f, Pal.RED, true), 6)
        put(label("GAME SPACE · Android Game Optimizer\nVersion 1.2.0\n\nDeveloper:\nSanju\n\nNo permissions, no network, no tracking, no ads.", 12f, Pal.text), 4)
    })
    return root
}
