package com.sanju.systemx.gamespace

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import com.sanju.systemx.R
import com.sanju.systemx.device.DeviceInfoProvider
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.ui.LineChartView
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.box
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.components.WRAP
import com.sanju.systemx.ui.components.lp
import com.sanju.systemx.ui.components.weight
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.ui.put
import java.util.Locale

/** MONITOR: real measurements only. UI FPS is this app's own rendering, never presented as game FPS. */
fun GameSpaceActivity.monitorSection(): View {
    val act = this
    val root = LinearLayout(this).apply { setPadding(dp(14), dp(6), dp(14), dp(10)) }
    val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    root.weight(left, 1f)
    root.weight(right, 1f, dp(12))

    val fpsChart = LineChartView(this, "UI FPS · Game Space only (not game FPS)", null)
    val ramChart = LineChartView(this, "SYSTEM RAM USED %", 100f)
    val metrics = label("Press START to measure.", 13f)
    val probe = View(this).apply { setBackgroundColor(Pal.RED) }
    var started = false

    fun begin() {
        if (started) return
        started = true
        monitor.start()
        probeAnim = ObjectAnimator.ofFloat(probe, "rotation", 0f, 360f).apply {
            duration = 1200; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator(); start()
        }
        val g = vm.graphics.value
        liveUpdater = { s ->
            fpsChart.push(s.fps); ramChart.push(s.ramPct)
            metrics.text = "UI FPS (render probe): ${Math.round(s.fps)}\n" +
                "CPU: ${s.cpu}\nCPU LOAD: ${getString(R.string.gpu_util_unavailable)}\n" +
                "GPU: ${g?.renderer ?: "Unavailable"}\nGPU UTILIZATION: ${getString(R.string.gpu_util_unavailable)}\n" +
                "GRAPHICS API: ${g?.apiSummary ?: "Unavailable"}\n" +
                "SYSTEM RAM: ${s.ramText}\nAPP MEMORY: ${s.heapMb} MB\n" +
                "BATTERY: ${if (s.battery >= 0) "${s.battery}%" else "n/a"}${if (s.charging) " (charging)" else ""}\n" +
                "BATTERY TEMPERATURE: ${s.tempC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "Unavailable"}\n" +
                "REFRESH: ${DisplayCtl.hz(act)} Hz"
        }
    }

    left.put(box("LIVE MONITOR").apply {
        put(fpsChart, 6)
        put(ramChart, 6)
        put(LinearLayout(act).apply {
            addView(label("Render probe (needed to measure UI FPS): ", 11f, Pal.sub))
            addView(probe, lp(dp(12), dp(12)))
        }, 6)
        if (!prefs.getB("autoMon", true)) put(btn("START MONITOR") { v -> v.isEnabled = false; begin() }, 8)
    }, 0)
    right.put(box("METRICS").apply { put(metrics, 6) }, 0)
    if (prefs.getB("showStats", true)) {
        right.put(box("DEVICE INFORMATION").apply {
            DeviceInfoProvider.rows(act, vm.graphics.value).forEach { (k, v) ->
                put(label("$k  ·  $v", 12f, Pal.text), 3)
            }
        })
    }
    if (prefs.getB("autoMon", true)) begin()
    return root
}
