package com.sanju.systemx.ui.components

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
val AMBER: Int = 0xFFFFB300.toInt()

fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

fun LinearLayout.weight(v: View, w: Float, startMargin: Int = 0) {
    addView(v, lp(0, WRAP, w).apply { marginStart = startMargin })
}

fun Context.iconOf(pkg: String): Drawable? = try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }

/** Small status chip used in the top bar. */
fun Context.tag(t: String, color: Int = Pal.sub): TextView = TextView(this).apply {
    text = t
    textSize = 11f
    setTextColor(color)
    typeface = Typeface.DEFAULT_BOLD
    setPadding(dp(8), dp(4), dp(8), dp(4))
    background = GradientDrawable().apply { setColor(Pal.panel2); cornerRadius = dp(6).toFloat() }
}

fun Context.smallBtn(t: String, onClick: (View) -> Unit): MaterialButton =
    btn(t, false, onClick).apply { textSize = 12f; minimumHeight = dp(38); minHeight = dp(38) }

/** Label + value row used by the real-time performance panel. */
class StatRow(ctx: Context, title: String, initial: String) {
    val value: TextView = ctx.label(initial, 13f, Pal.text, true).apply { gravity = Gravity.END }
    val view: LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, ctx.dp(3), 0, ctx.dp(3))
        addView(ctx.label(title, 12f, Pal.sub), lp(0, WRAP, 1f))
        addView(value, lp(WRAP, WRAP))
    }
}

/** Skewed HUD card with a red glow when active. */
class SkewCardDrawable(private val active: Boolean) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val path = Path()

    override fun onBoundsChange(bounds: Rect) {
        val sk = bounds.height() * 0.14f
        path.reset()
        path.moveTo(bounds.left + sk + 6f, bounds.top + 6f)
        path.lineTo(bounds.right - 6f, bounds.top + 6f)
        path.lineTo(bounds.right - sk - 6f, bounds.bottom - 6f)
        path.lineTo(bounds.left + 6f, bounds.bottom - 6f)
        path.close()
        fill.shader = LinearGradient(bounds.left.toFloat(), 0f, bounds.right.toFloat(), 0f,
            if (active) 0xFF241017.toInt() else Pal.panel, Pal.panel, Shader.TileMode.CLAMP)
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, fill)
        if (active) for (i in 3 downTo 1) {
            line.color = Pal.RED; line.alpha = 24; line.strokeWidth = i * 7f
            canvas.drawPath(path, line)
        }
        line.color = if (active) Pal.RED else 0xFF55555E.toInt()
        line.alpha = 255; line.strokeWidth = 3f
        canvas.drawPath(path, line)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
